# solon-landing
Lightweight &amp; fast lading page for a digital agency from Cluj-Napoca.
